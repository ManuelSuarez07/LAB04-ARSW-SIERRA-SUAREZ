package edu.eci.arsw.springdemo;

import org.springframework.stereotype.Service;
import org.springframework.context.annotation.Primary;

@Service
@Primary // Ahora SpanishSpellChecker será la opción predeterminada
public class SpanishSpellChecker implements SpellChecker {
    @Override
    public String checkSpell(String text) {
        return "Revisando (" + text + ") con el verificador de sintaxis del español";
    }
}
