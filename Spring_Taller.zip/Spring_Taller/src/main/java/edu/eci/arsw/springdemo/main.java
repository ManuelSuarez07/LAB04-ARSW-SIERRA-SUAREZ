package edu.eci.arsw.springdemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class main {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        GrammarChecker gc = context.getBean(GrammarChecker.class);
        System.out.println(gc.check("la la la"));
    }
}
