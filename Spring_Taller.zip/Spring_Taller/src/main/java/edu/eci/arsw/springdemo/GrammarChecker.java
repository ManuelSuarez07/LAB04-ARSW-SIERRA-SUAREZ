package edu.eci.arsw.springdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GrammarChecker {
    private SpellChecker sc;

    @Autowired
    public GrammarChecker(SpellChecker sc) { // Spring inyectará SpanishSpellChecker automáticamente
        this.sc = sc;
    }

    public String check(String text) {
        StringBuilder sb = new StringBuilder();
        sb.append("Spell checking output: ").append(sc.checkSpell(text)).append("\n");
        sb.append("Plagiarism checking output: Not available yet");
        return sb.toString();
    }
}
